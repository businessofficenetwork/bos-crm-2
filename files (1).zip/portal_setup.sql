-- ============================================================
-- BON CONTRACTOR PORTAL — DATABASE SETUP
-- Run this in your Supabase SQL Editor (one paste, one run)
-- Project: ezfrtcbmyifevyepgoym.supabase.co
-- ============================================================
-- Adds TWO tables to your existing BOS-CRM schema.
-- Does NOT touch contractors, claims, or supplements.
-- ============================================================

-- 1. PORTAL USERS
CREATE TABLE IF NOT EXISTS portal_users (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  contractor_id    uuid NOT NULL REFERENCES contractors(id) ON DELETE CASCADE,
  username         text NOT NULL UNIQUE,
  portal_password  text NOT NULL,
  display_name     text,
  is_active        boolean DEFAULT true,
  last_login       timestamptz,
  created_at       timestamptz DEFAULT now(),
  updated_at       timestamptz DEFAULT now()
);

-- 2. PORTAL MESSAGES
CREATE TABLE IF NOT EXISTS portal_messages (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  contractor_id    uuid NOT NULL REFERENCES contractors(id) ON DELETE CASCADE,
  sender           text NOT NULL CHECK (sender IN ('bon','contractor')),
  message          text NOT NULL,
  is_read          boolean DEFAULT false,
  created_at       timestamptz DEFAULT now()
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_portal_users_contractor    ON portal_users(contractor_id);
CREATE INDEX IF NOT EXISTS idx_portal_users_username      ON portal_users(username);
CREATE INDEX IF NOT EXISTS idx_portal_messages_contractor ON portal_messages(contractor_id);
CREATE INDEX IF NOT EXISTS idx_portal_messages_unread
  ON portal_messages(contractor_id, is_read) WHERE is_read = false;

-- ============================================================
-- ADD YOUR FIRST PILOT CONTRACTOR
-- Step 1 — find the contractor UUID:
--   SELECT id, name FROM contractors;
--
-- Step 2 — create their portal login:
--   INSERT INTO portal_users (contractor_id, username, portal_password, display_name)
--   VALUES (
--     'PASTE-CONTRACTOR-UUID-HERE',
--     'crownexteriors',
--     'bon2025',
--     'Crown Exteriors'
--   );
-- ============================================================

-- VERIFY: both tables exist
-- SELECT table_name FROM information_schema.tables
--   WHERE table_schema = 'public'
--   AND table_name IN ('portal_users','portal_messages');
